package com.sts;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "certificate")
public class Certificate {

    @Id
    private Long student_id;
    private String student_name;
    private String branch;
    private String company;
    private int yearofcompletion;

    // Getters and Setters

    public Long getStudentId() {
        return student_id;
    }

    public void setStudent_id(Long student_id) {
        this.student_id = student_id;
    }

    public String getStudentName() {
        return student_name;
    }

    public void setStudent_name(String student_name) {
        this.student_name = student_name;
    }

    public String getBranch() {
        return branch;
    }

    public void setBranch(String branch) {
        this.branch = branch;
    }

    public String getCompany() {
        return company;
    }

    public void setCompany(String company) {
        this.company = company;
    }

    public int getYearOfCompletion() {
        return yearofcompletion;
    }

    public void setYearofcompletion(int yearofcompletion) {
        this.yearofcompletion = yearofcompletion;
    }
}


