package com.sts.service;

import com.sts.Certificate;
import com.sts.repository.CertificateRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class CertificateService {

    @Autowired
    private CertificateRepository repository;

    public List<Certificate> getAllCertificates() {
        return repository.findAll();
    }

    public Optional<Certificate> getCertificateById(Long id) {
        return repository.findById(id);
    }

    public Certificate saveCertificate(Certificate certificate) {
        return repository.save(certificate);
    }

    public void deleteCertificate(Long id) {
        repository.deleteById(id);
    }
}

