package com.sts.controller;

import com.sts.Certificate;
import com.sts.service.CertificateService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/certificates")
public class CertificateController {

    @Autowired
    private CertificateService service;

    @GetMapping
    public List<Certificate> getAllCertificates() {
        return service.getAllCertificates();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Certificate> getCertificateById(@PathVariable Long id) {
        Optional<Certificate> certificate = service.getCertificateById(id);
        return certificate.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
    }

    @PostMapping
    public Certificate createCertificate(@RequestBody Certificate certificate) {
        return service.saveCertificate(certificate);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteCertificate(@PathVariable Long id) {
        service.deleteCertificate(id);
        return ResponseEntity.noContent().build();
    }
    @PutMapping("/{id}")
    public ResponseEntity<Certificate> updateCertificate(@PathVariable Long id, @RequestBody Certificate updatedCertificate) {
        Optional<Certificate> existingCertificate = service.getCertificateById(id);
        if (existingCertificate.isPresent()) {
            // Update the existing certificate with new values
            Certificate certificate = existingCertificate.get();
            certificate.setStudent_id(updatedCertificate.getStudentId());
            certificate.setStudent_name(updatedCertificate.getStudentName());
            certificate.setBranch(updatedCertificate.getBranch());
            certificate.setCompany(updatedCertificate.getCompany());
            certificate.setYearofcompletion(updatedCertificate.getYearOfCompletion());

            Certificate updated = service.saveCertificate(certificate);
            return ResponseEntity.ok(updated);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    }



    



